
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAKEBOOK - Buy & Sell Used Books</title>
    <link rel="stylesheet" href="Home.css">
</head>

<body>
    <header>
        <h1>TAKEBOOK</h1>
        <p>Rent-Read-Return</p>
        <!-- <button style="font: size 25px; background-colour:purple ; border-radius:25px"> Home </button> -->
        <section>
        <div class = "Home">
            <button>Home </button>
        </div>
        <div class = "LOG IN">
            <button>LOG IN </button>
        </div>
</section>

    </header>

    <main>
        <section>
            <div class="about">
                <h2>Welcome to TAKEBOOK!</h2>
                <p>We're passionate about books and giving them a second life. Whether you're looking to declutter your
                shelves or discover hidden treasures, TAKEBOOK is the perfect place for you.</p>
               
            </div>
            
            
        </section>

        <section class="buy-sell">
            <div class="buy">
                <h2>Buy Used Books</h2>
                <p>Find a wide range of used books at great prices. Explore by genre, author, or keyword.</p>
                <a href="#">Browse Books</a>
            </div>
            <div class="sell">
                <h2>Sell Your Books</h2>
                <p>Give your pre-loved books a new home and earn some cash. Learn more about selling on TAKEBOOK.</p>
                <a href="#">Learn More</a>
            </div>
            
        </section>
    </main>

    <footer>
        <p>&copy; TAKEBOOK 2024</p>
    </footer>

    <script src="script.js"></script>
</body>

</html>