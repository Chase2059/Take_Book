// Add functionality to links (e.g., open in new tab)
const links = document.querySelectorAll('a');
links.forEach(link => {
    link.addEventListener('click', (event) => {
        event.preventDefault();
        window.open(link.href, '_blank');
    });
});
