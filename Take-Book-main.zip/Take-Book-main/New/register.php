<?php
#include 'connection.php';

// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$city = $_POST['city'];
$zip = $_POST['zip'];
$dob = $_POST['dob'];
$user_id = $_POST['username'];
$password = $_POST['password'];

// Prepare SQL statement to insert data into the database
$sql = "INSERT INTO customer (name, email, phone, address, city, zip, dob, user_id, password)
        VALUES ('$name', '$email', '$phone', '$address', '$city', '$zip', '$dob', '$user_id', '$password')";

if ($conn->query($sql) === TRUE) {
    echo "Registration successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$sql = "Insert into user (user_id, password) values ('$user_id', '$password')";
if ($conn->query($sql) === TRUE) {
    echo "Registration successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>
<html>

<body>
    <br>
    <a href="index.html">Home</a>
</body>

</html>