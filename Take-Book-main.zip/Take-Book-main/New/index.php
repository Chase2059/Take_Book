<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <img src="logo.png" alt="logo" class="logo">
    <div class="container">
        <div class="header">
            <h1 class="Comp_name">Take Book</h1>
        </div>
        <div>
            <h3 class="tag_line">RENT-READ-RETURN</h3>
        </div>
        <div>
            <a href="aboutus.php" class="aboutus">About Us</a>
        </div>
        <div>
            <a href="login.php" class="login">Login</a>
        </div>
</body>

</html>