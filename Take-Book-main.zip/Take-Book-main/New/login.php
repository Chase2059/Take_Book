<!DOCTYPE html>
<html>

<head>
    <title>Login Page</title>
    <link rel="stylesheet" type="text/css" href="stylelogin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>

    <form action="login.php" method="post">
        <label for="userid">Userid:</label>
        <input type="text" id="user_id" name="username" required><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>

        <input type="submit" value="Login"><br><br>
        <p>New User <a href="registerpage.php">register</a></p>
    </form>
</body>

</html>
<!-- <?php

#include 'connection.php';

// Retrieve username and password from form
$user_id = $_POST['userid'];
$password = $_POST['password'];

// Prepare SQL statement to fetch user from database
$sql = "SELECT * FROM user WHERE user_id = '$user_id' AND password = '$password'";
$result = $conn->query($sql);

// Check if user exists
if ($result->num_rows > 0) {
    echo "Login successful!";
} else {
    echo "Invalid username or password.";
}

// Close connection
$conn->close();
?> -->