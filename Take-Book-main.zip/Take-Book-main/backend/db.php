<?php
echo "This is database file.";